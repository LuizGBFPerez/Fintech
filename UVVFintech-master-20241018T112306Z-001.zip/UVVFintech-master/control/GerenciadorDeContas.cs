﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UVVFintech.model;

namespace UVVFintech.control
{
    internal class GerenciadorDeContas
    {
        private Conta modeloPersistenciaConta;

        public void adicionarConta(Conta conta) { 
        
        }

        public void removerConta(Conta conta) {
            
        }

        public void retornarConta(int id)
        {

        }
    }
}
